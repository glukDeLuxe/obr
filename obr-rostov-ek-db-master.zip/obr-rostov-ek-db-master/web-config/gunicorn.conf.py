#! coding: utf-8
import os
import multiprocessing
import datetime
 
current_dir = os.path.abspath(os.path.dirname(__file__))# папка с программой
dirs = current_dir.rsplit(os.sep, 3)
short_name = 'ssuz' # Имя установки для сокета
proc_dir = os.path.join(*dirs[0:-1])
run_dir = os.path.join(proc_dir, 'var/run') # путь до pid- и сокет- файлов
#bind = "127.0.0.1:8989"
bind = "unix:%s/%s.sock" % (run_dir, short_name)
print("!!! This is socket:", bind, ", current time:", datetime.datetime.now())
proc_name = "%s/%s" % (run_dir, short_name)
workers = multiprocessing.cpu_count() * 2 + 1
user = "bars"
group = "bars"
errorlog = "%s/var/log/gunicorn.log" % proc_dir
loglevel = "info"
pidfile = "%s/%s.pid" % (run_dir, short_name)
timeout = 1800
max_requests = 500
